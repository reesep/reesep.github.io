
public class Program5Demo {

	public static void main(String[] args) {
		
		MazeSolver m = new MazeSolver();
		m.solveMaze();
	
	}

}
