
public class GuessingGameDemo {

	public static void main(String[] args) {
		GuessingGame game = new GuessingGame();
		game.playGame();

	}

}
