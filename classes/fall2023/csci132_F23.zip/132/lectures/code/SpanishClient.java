
public class SpanishClient implements ClientMethods{

	public void greet() {
		System.out.println("Hola");
	}
	
	public void goodbye() {
		System.out.println("Adios");
	}
	
}
