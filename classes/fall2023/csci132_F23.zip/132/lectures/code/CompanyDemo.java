
public class CompanyDemo {

	public static void main(String[] args) {
		
		Programmer reese = new Programmer("Reese",123,80000,"Python");
		System.out.println(reese.getName());
		/*
		Accountant kevin = new Accountant("Kevin",555,55000,'B');
		System.out.println(kevin.getGrade());
		
		Lawyer saul = new Lawyer("Saul",999,120000,456);
		System.out.println(saul.getName());
		*/
	}

}
