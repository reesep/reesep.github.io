
public class FrenchClient implements ClientMethods {

	public void greet() {
		System.out.println("Bonjour");
	}
	
	public void goodbye() {
		System.out.println("Au Revoir");
	}
	
}
