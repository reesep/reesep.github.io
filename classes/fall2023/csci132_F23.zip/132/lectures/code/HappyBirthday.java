
public class HappyBirthday {

	public static void sing(String name) {
		System.out.println("Happy Birthday to you");
		System.out.println("Happy Birthday to you");
		System.out.println("Happy Birthday dear " + name);
		System.out.println("Happy Birthday to you");
	}
	
	
}
