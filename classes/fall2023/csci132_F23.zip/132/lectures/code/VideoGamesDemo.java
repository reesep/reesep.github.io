
public class VideoGamesDemo {

	public static void main(String[] args) {
		
		VideoGames gaming = new VideoGames();
		//gaming.findMaxScore();
		gaming.getNumPlayersInfo();
		

	}

}
