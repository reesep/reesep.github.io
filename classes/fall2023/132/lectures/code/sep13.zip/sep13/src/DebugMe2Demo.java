
public class DebugMe2Demo {

	public static void main(String[] args) {
		
		Book my_book = new Book("Lord of the Flies","William Golding",1954);
		
		my_book.print_info();

	}

}
