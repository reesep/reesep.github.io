
public class PokerHand {

	private Card[] hand = new Card[3];
	
	public PokerHand(Card c1, Card c2, Card c3) {
		hand[0] = c1;
		hand[1] = c2;
		hand[2] = c3;
	}
	
	public void printHand() {
		for(Card c: this.hand) {
			System.out.println(c);
		}
	}
	
	public void evaluate() {
		
		if(three_of_a_kind()) {
			System.out.println("Three of a kind detected");
		}
		
	}
	
	public boolean three_of_a_kind() {
		if(hand[0].getRank() == hand[1].getRank() && hand[1].getRank() == hand[2].getRank()) {
			return true;
		}
		else {
			return false;
		}
	}

	
}
