
public class CircularDoublyLinkedListDemo {

	public static void main(String[] args) {
		
		CircularDoublyLinkedList cll = new CircularDoublyLinkedList();
		
		cll.fillLinkedList("airports.txt");
		
		cll.printLinkedList();

	}

}
