
public class EnglishClient implements ClientMethods{

	@Override
	public void greet() {
		System.out.println("Hello");
	}

	@Override
	public void goodbye() {
		System.out.println("Goodbye");
	}

	
}
