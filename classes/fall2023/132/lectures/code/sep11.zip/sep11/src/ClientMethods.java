
public interface ClientMethods {
	
	public void greet();
	public void goodbye();
	
}
