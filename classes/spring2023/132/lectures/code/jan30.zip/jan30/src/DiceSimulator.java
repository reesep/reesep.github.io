
import java.util.Random;

public class DiceSimulator {

	private int num_of_rolls;
	private int num_of_sides;
	
	private String[] frequency;
	
	
	public DiceSimulator(int inRolls, int inSides) {
		this.num_of_rolls = inRolls;
		this.num_of_sides = inSides;
		
		this.frequency = new String[num_of_sides + 1];
	}
	
	
	public void simulate() {
		int min = 1;
		int max = num_of_sides;
		for(int i = 0; i < this.num_of_rolls; i++) {
			int random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
			System.out.println(random_int);
		}
	}
	
	public void printResults() {
		
	}
	
}
