
public class PokerHand {

	private Card[] hand = new Card[3];
	
	public PokerHand(Card card1, Card card2, Card card3) {
		this.hand[0] = card1;
		this.hand[1] = card2;
		this.hand[2] = card3;
	}
	
	public static boolean three_of_a_kind(PokerHand h) {
		
		if(h.hand[0] == h.hand[1] && h.hand[1] == h.hand[2]) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public void evaluate() {
		
		if(three_of_a_kind(this)) {
			System.out.println("Three of a kind detected!!");
		}
		
	}
}
