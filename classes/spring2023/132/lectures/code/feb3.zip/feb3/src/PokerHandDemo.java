
public class PokerHandDemo {

	public static void main(String[] args) {
		
		
		PokerHand pokerhand1 = new PokerHand(new Card("Hearts",6), new Card("Diamonds",6), new Card("Spades",6));
		
		pokerhand1.evaluate();
		
				
		

	}

}