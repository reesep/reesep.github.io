
public interface AnimalSound {

	public void makeSound();
	
}
