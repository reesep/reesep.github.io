package jan23;

public class HelloWorld {

	public static void main(String[] args) {
		

		int year = 2023;
		double decimal = 4.0;

		char character = 'F';
		
		boolean bool = true;
		
		String s = "Reese";
		
		String last = " Pearsall";
		
		String answer = s + last;
		
		System.out.println(answer);
		
		int counter = 0;
		counter--;
		System.out.println(counter);
		counter--;
		System.out.println(counter);
		counter++;
		System.out.println(counter);
		counter++;
		System.out.println(counter);
		
		
		
		
		

	}

	
}
