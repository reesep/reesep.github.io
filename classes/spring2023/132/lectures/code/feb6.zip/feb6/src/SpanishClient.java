
public class SpanishClient {

}
