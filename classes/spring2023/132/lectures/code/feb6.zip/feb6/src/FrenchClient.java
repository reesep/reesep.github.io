
public class FrenchClient {

}
