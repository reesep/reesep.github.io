import java.util.Arrays;

public class MinHeap {

	private int[] data;
	
	private int capacity;
	private int size;
	
	public MinHeap() {
		this.data = new int[5];
		this.capacity = 5;
		this.size = 0;
	}
	
	
	public void add(int newItem) {
		
		addMoreCapacityIfNeeded();
		data[size] = newItem;
		size++;
		
		heapifyUp();
		
	}
	
	public int poll() {
		if(size == 0) {
			return -1;
		}
		
		int min = data[0];
		data[0] = data[size -1];
		size--;
		
		heapifyDown();
		
		return min;
	}
	
	public void heapifyDown() {
		int current = 0;
		while(hasLeftChild(current)) {
			
			int smallerChildIndex = getLeftChildIndex(current);
			if(hasRightChild(current) && data[getRightChildIndex(current)] < data[getLeftChildIndex(current)]) {
				smallerChildIndex = getRightChildIndex(current);
			}
			
			if(data[current] < data[smallerChildIndex]) {
				break;
			}
			else {
				swap(current, smallerChildIndex);
			}
			
			current = smallerChildIndex;
			
	
		}
	}
	
	public void heapifyUp() {
		int current = size - 1;
		while(hasParent(current) && data[getParentIndex(current)] > data[current]) {
			swap(getParentIndex(current),  current);
			current = getParentIndex(current);
		}
	}
	
	public void swap(int indexOne, int indexTwo) {
		int temp = data[indexOne];
		data[indexOne] = data[indexTwo];
		data[indexTwo] = temp;
	}
	
	public void addMoreCapacityIfNeeded() {
		
		if(size == capacity) {
			data = Arrays.copyOf(data, capacity+1);
			capacity++;
		}
	}
	
	//Helper Methods
	public int getLeftChildIndex(int parentIndex) {
		return 2 * parentIndex + 1;
	}
	
	public int getRightChildIndex(int parentIndex) {
		return 2 * parentIndex + 2;
	}
	
	public int getParentIndex(int childIndex) {
		return (childIndex - 1) / 2;
	}
	
	public boolean hasLeftChild(int index) {
		return getLeftChildIndex(index) < size;
	}
	
	public boolean hasRightChild(int index) {
		return getRightChildIndex(index) < size;
	}
	
	public boolean hasParent(int index) {
		return index > 0;
	}
	
}
