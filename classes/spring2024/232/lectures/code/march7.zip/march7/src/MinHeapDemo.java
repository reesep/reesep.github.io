
public class MinHeapDemo {

	public static void main(String[] args) {
		MinHeap heap = new MinHeap();
		
		heap.add(10);
		heap.add(7);
		heap.add(15);
		heap.add(2);
		heap.add(42);
		heap.add(3);
		heap.add(15);
		
		
		System.out.println(heap.poll());
		System.out.println(heap.poll());
		System.out.println(heap.poll());
		System.out.println(heap.poll());
	}
}
