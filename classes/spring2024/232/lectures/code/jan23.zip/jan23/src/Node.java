
public class Node {

	private Item item;
	private Node next;
	
	public Node(Item i) {
		this.item = i;
		this.next = null;
	}
	
	public Item getItem() {
		return this.item;
	}
	
	public Node getNext() {
		return this.next;
	}
	
	public void setNext(Node nextNode) {
		this.next = nextNode;
	}
	
}
