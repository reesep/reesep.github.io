import java.util.LinkedList;
public class ShoppingCartLinkedList {

	private LinkedList<Item> shoppingCart;
	private int num_of_items;
	
	public ShoppingCartLinkedList() {
		this.shoppingCart = new LinkedList<Item>();
		this.num_of_items = 0;
	}
	
	public void addItem(String n, double p, int q) {
		Item newItem = new Item(n,p,q);
		shoppingCart.add(newItem);
		this.num_of_items++;
	}
	
	public void searchForItem(String name) {
		
	}
	

	
	public void removeItem(String name) {
		
	}
	
	public void printCart() {
		System.out.println("Shopping Cart");
		System.out.println("--------------");

		for(Item i: shoppingCart) {
			System.out.println(i.getName() + " " + i.getPrice() + " " + i.getQuantity());
		}
		
	}
	
	
}
