
public class ShoppingCartDemo {

	public static void main(String[] args) {
		
		//Item i1 = new Item("Milk",2.99,1);
		//Item i2 = new Item("Cheese",1.99,3);
		
		ShoppingCartLinkedList cart = new ShoppingCartLinkedList();
		cart.addItem("Milk",2.99,1);
		cart.addItem("Flour",5.99,1);
		cart.addItem("Cheese",1.99,4);
		
		cart.printCart();
		

		
		
	}

}
