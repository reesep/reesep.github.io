
public class ShoppingCartArray {

	private Item[] shoppingCart;
	private int num_of_items;
	
	public ShoppingCartArray() {
		this.shoppingCart = new Item[0];
		this.num_of_items = 0;
	}
	
	public void addItem(String name, double price, int quantity) {
		Item item = new Item(name, price, quantity);

		Item[] tempArray = new Item[shoppingCart.length+1];
		
		for(int i = 0; i < shoppingCart.length; i++) {
			tempArray[i] = shoppingCart[i];
		}
		
		tempArray[shoppingCart.length] = item;
		shoppingCart = tempArray;
		num_of_items++;
		
	}
	
	public void printCart() {
		for(Item i: shoppingCart) {
			System.out.println(i.getName() + " " + i.getPrice() + " " + i.getQuantity());
		}
	}

	public double getTotal() {
		double total = 0;
		for(Item i: shoppingCart) {
			total += (i.getPrice() * i.getQuantity());
		}
		return total;
	}

	public void applyCoupon(String itemName, double discount) {
		
		for(Item i: shoppingCart) {
			if(i.getName().equals(itemName)) {
				i.setPrice(i.getPrice() - (i.getPrice() * discount));
			}
		}
		
	}
	
	public void searchForItem(String name) {

	}
	
	public void removeItem(String name) {
		
	}
	
}
