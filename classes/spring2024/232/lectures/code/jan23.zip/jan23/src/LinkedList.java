
public class LinkedList {

	private Node head;
	private int size;
	
	public LinkedList() {
		this.head = null;
		this.size = 0;
	}
	
	public void addItemToLinkedList(Item item) {
		Node newNode = new Node(item);
		
		if(head == null) {
			head = newNode;
		}
		else {
			newNode.setNext(head);
			head = newNode;
		}
		this.size++;
		
	}

	public void printLinkedList() {
		Node current = head;
		while(current != null) {
			System.out.println(current.getItem().getName());
			current = current.getNext();
		}
		
		
	}
	
	
	
	
	
}
