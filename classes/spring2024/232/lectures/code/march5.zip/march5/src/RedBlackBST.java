import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class RedBlackBST {

	private Node root;
	
	public RedBlackBST() {
		this.root = null;
	}
	
	public Node getRoot() {
		return this.root;
	}
	
	//This is not an insert method for a red black tree.
	// This is a normal BST insert method
	public void insert(int newValue, String color) {
		
		if(root == null) {
			root = new Node(newValue,color);
		}
		else {
			
			Node currentNode = root;
			boolean placed = false;
			
			while(!placed) {
				
				if(currentNode.getValue() == newValue) {
					placed = true;
					System.out.println("No duplicate values allowed");
				}
				else if(newValue < currentNode.getValue()) {
					//move left
					if(currentNode.getLeft() == null) {
						// cant move left, so we found insertion spot
						//insert Node
						currentNode.setLeft(new Node(newValue,color));
						currentNode.getLeft().setParent(currentNode);
						placed = true;
					}
					else {
						// otherwise move left
						currentNode = currentNode.getLeft();
					}
				}
				else {
					//move right
					if(currentNode.getRight() == null) {
						//cant move right, insert new node
						currentNode.setRight(new Node(newValue,color));
						currentNode.getRight().setParent(currentNode);
						placed = true;
					}
					else {
						//move right
						currentNode = currentNode.getRight();
					}
				}
				
				
			}
			
			
			
		}
		
		
		
		
	}
	

	public void verifyRedBlackTree() {
		
		if(rule1()) {
			System.out.println("Rule 1: Every node is either red or black ✔️");
		}
		if(rule2()) {
			System.out.println("Rule 2: The null children are black ✔️");
		}
		if(rule3()) {
			System.out.println("Rule 3: The root node is black ✔️");
		}
		if(rule4()) {
			System.out.println("Rule 4: If a node is red, both children must be black ✔️");
		}
		if(rule5(root)) {
			System.out.println("Rule 5: Paths contain the same number of black nodes ✔️");
		}

	}

	private boolean rule1() {
		//Rule 1: Every node is either red or black
		Queue<Node> queue = new LinkedList<>();
		if(root != null) {
			queue.add(root);
			
			while(!queue.isEmpty()) {
				Node node = queue.remove();
				
				if(node.getColor().equals("Black") || node.getColor().equals("Red")) {
					//good
				}
				else {
					return false;
				}
				
				if(node.getLeft() != null) {
					queue.add(node.getLeft());
				}
				if(node.getRight()!= null) {
					queue.add(node.getRight());
				}
				
				
			}
			return true;
		}
		else {
			return false;
		}
		
	}

	private boolean rule2() {
		//Rule 2: The null children are black
		
		return true;
	}

	private boolean rule3() {
		//Rule 3: The root node is black
		if(root != null) {
			if(!root.getColor().equals("Black")) {
				return false;
			}
			else {
				return true;
			}
		}
		else {
			return false;
		}
	}

	private boolean rule4() {
		//Rule 4: If a node is red, both children must be black
		Queue<Node> queue = new LinkedList<>();
		if(root != null) {
			queue.add(root);
			
			while(!queue.isEmpty()) {
				Node node = queue.remove();
				
				// do action
				if(node.getColor().equals("Red")) {
					
					HashSet<Node> children = new HashSet<>();
					children.add(node.getLeft());
					children.add(node.getRight());
					
					for(Node n: children) {
						
						if(n != null) {
							if(!n.getColor().equals("Black")) {
								return false;
							}
						}
						
					}
					
				}
				
				if(node.getLeft() != null) {
					queue.add(node.getLeft());
				}
				if(node.getRight()!= null) {
					queue.add(node.getRight());
				}
				
				
			}
		return true;
		}
		else {
			return false;
		}
	}

	private boolean rule5(Node startNode) {
		//Rule 5: All paths from startNode to descendant leaves contain the same number of black nodes
		HashSet<Node> leaves = new HashSet<>();
		Queue<Node> queue = new LinkedList<>();
		if(root != null) {
			queue.add(root);
			
			while(!queue.isEmpty()) {
				Node node = queue.remove();
			
				if(node.getLeft() == null && node.getRight() == null) {
					leaves.add(node);
				}
				
				if(node.getLeft() != null) {
					queue.add(node.getLeft());
				}
				if(node.getRight()!= null) {
					queue.add(node.getRight());
				}	
			}
		} //end the breadth first
		
		HashMap<Integer, Integer> paths = new HashMap<>();
		for(Node n: leaves) {
			
			Node current = n;
			int blackNodesVisited = 1;
			while(current != null) {
				
				if(current.getColor().equals("Black")) {
					blackNodesVisited++;
				}
				current = current.getParent();
				
			}
			paths.put(n.getValue(), blackNodesVisited);

		} //now the hashmap is filled
		List<Integer> values = new LinkedList(paths.values());
		Set<Integer> noDupes = new HashSet<>(values);
		
		if(noDupes.size() == 1) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	
	
	
}
