
public class RedBlackVerifierDemo {

	public static void main(String[] args) {
		
		// Not an actual Red Black Tree
		// Simply a class that verifies if a tree is a red black tree or not
		RedBlackBST rbtree = new RedBlackBST();

		rbtree.insert(10, "Black");
		
		rbtree.insert(2, "Black");
		rbtree.insert(18, "Red");
		
		rbtree.insert(12, "Black");
		rbtree.insert(50, "Black");
		
		rbtree.insert(17, "Red");
		
		
		rbtree.verifyRedBlackTree();
		
	}

}
