
public class Node {

	private int value;
	
	private Node left;
	private Node right;
	
	private Node parent;
	
	private String color;
	
	public Node(int newValue, String c) {
		this.value = newValue;
		this.color = c;
	}
	
	//getter methods
	public int getValue() {
		return this.value;
	}
	
	public Node getParent() {
		return this.parent;
	}
	
	public Node getLeft() {
		return this.left;
	}
	
	public Node getRight() {
		return this.right;
	}
	
	public String getColor() {
		return this.color;
	}
	
	//setter
	public void setParent(Node newParent) {
		this.parent = newParent;
	}
	
	public void setLeft(Node newLeft) {
		this.left = newLeft;
	}
	
	public void setRight(Node newRight) {
		this.right = newRight;
	}

	public void setValue(int newValue) {
		this.value = newValue;
		
	}
	
}
