import java.util.HashSet;
import java.util.LinkedList;

public class WeightedDirectedGraph {

	// vertices are integers
	private LinkedList<Edge>[] adjList;
	
	//for program3
	//private HashMap<String, LinkedList<Edge>> adjList;
	
	//store all edges of graph-- no duplicate edges
	private HashSet<Edge> edges;
	
	public WeightedDirectedGraph(int numVertices) {
		adjList = new LinkedList[numVertices];
		
		for(int i = 0; i < adjList.length; i++) {
			adjList[i] = new LinkedList<>();
		}
		
		edges = new HashSet<Edge>();
	}
	
	public int getNumVertices() {
		return adjList.length;
	}
	
	public int getNumEdges() {
		return edges.size();
	}
	
	public HashSet<Edge> getEdges(){
		return edges;
	}
	
	//Given some vertex, returns the edges that we can travel on directly from that edge ("adjacent edges")
	public LinkedList<Edge> getAdjacencyEdges(int vertex){
		return adjList[vertex];
	}
	
	public void addEdge(int sourceVertex, int destVertex, double weight) {
		Edge edge = new Edge(sourceVertex, destVertex, weight);
		
		if(edges.add(edge)) {
			adjList[sourceVertex].add(edge);
		}
		
		
	}

	public void printAdjList() {
		
		for(int i = 0; i < adjList.length; i++) {
			System.out.println(i + ": " + adjList[i]);
		}
		
	}
	
}
