import java.util.LinkedList;
import java.util.PriorityQueue;

public class ShortestPath {

	
	private double[] distance; //best estimates to each vertex
	private Edge[] previous; //keeps track of the Edge that got us to that vertex

	//For program these, these two data structures will be HashMaps
	
	public void computeShortestPath(WeightedDirectedGraph graph, int start) {
		//Dijkstra's Algorithm
		distance = new double[graph.getNumVertices()];
		for(int i = 0; i < distance.length; i++) {
			distance[i] = Double.POSITIVE_INFINITY; //best estimates are all infinity at first
		}
		distance[start] = 0; //the distance to our starting point is always 0
		
		previous = new Edge[graph.getNumVertices()];
		PriorityQueue<PriorityVertex> visitQueue = new PriorityQueue<PriorityVertex>();
		visitQueue.add( new PriorityVertex(start, 0) );
		while(!visitQueue.isEmpty()) {
			
			PriorityVertex vertex = visitQueue.poll();
			//Check all the paths we can travel on with our new vertex
			for(Edge edge: graph.getAdjacencyEdges(vertex.getVertex())) {
				
				int neighbor = edge.getTo();
				if(distance[vertex.getVertex()] + edge.getWeight() < distance[neighbor]) {
					
					//we found a new best estimate, so update our data structures
					distance[neighbor] = distance[vertex.getVertex()] + edge.getWeight();
					previous[neighbor] = edge;
					
					//We need to remove the old vertex from the PQ and insert the new one
					visitQueue.remove( new PriorityVertex(neighbor, 0)  ); // 0 can be any number
					visitQueue.add( new PriorityVertex(neighbor, distance[neighbor]));
					
					
				}
				
			}
			
			
			
		}
		
		
	}

	//Determines if we have a path after Dijkstra's.
	//    The best estimate for destination will still be infinity if we never touched it
	public boolean hasPath(int destination) {
		return distance[destination] < Double.POSITIVE_INFINITY;
	}
	
	
	//Backtracks through the "previous" array and assembles our shortest path
	public LinkedList<Edge> getPathTo(int destination) {
		
		if( !hasPath(destination)) {
			return null;
		}
		else {
			LinkedList<Edge> solution = new LinkedList<Edge>();
			for(Edge edge = previous[destination]; edge != null; edge = previous[edge.getFrom()]) {
				solution.addFirst(edge);
			}
			return solution;
			
		}
		
	}
	
	

}
