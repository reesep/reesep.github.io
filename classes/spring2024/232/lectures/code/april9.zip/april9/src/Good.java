// Things to notice that are "good"
// Comments explaining methods (complex lines of code should have a comment too)
// Class name is capitalized
// variable names are not capitalized (snake case and camel case are both good options)
// Indentation and Spacing is very consistent (indented inside methods, if statements, loops) 
// No dead code and no large commented out blocks of code. 
//    Relevant methods that are not called in your program are ok.


//Reese Pearsall, Program X, CSCI 232

public class Good {

    public static void main(String[] args) {
        int number = 5; 
        long factorial = calculateFactorial(number);
        System.out.println("Factorial of " + number + " = " + factorial);
    }

    //Recursively computes the factorial of some number n:  n * n-1 * n-2 * n-3 * ... * 1
    public static long calculateFactorial(int n) {
    	//base case
        if (n == 0 || n == 1) {
            return 1;
        } 
        else {
        	//recursive case
            return n * calculateFactorial(n - 1);
        }
    }
}
