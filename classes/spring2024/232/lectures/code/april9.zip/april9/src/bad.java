// Things to notice that are "bad"
// Lack of comments
// Class name is not capitalized
// variable names are capitalized
// Indentation and Spacing is very inconsistent
// Large chunks of commented out code


public class bad {

	public static void main(String[] args) {
        int Number = 5; 
        		int  FACTORIAL = CalculateFactorial(  Number);
        System.out.println("Factorial of " + Number + " = " + FACTORIAL);
 }


    //public static int CalculateFactorial(int n) {
//for(i=1;i<=n;i++){    
	  //    fact=fact*i;    
	 // }    
	 // System.out.println("Factorial of "+number+" is: "+fact);    
	 //return fact;
 //}
	
	
    public static int CalculateFactorial(int n) {
if (n == 0 || n == 1) {
            		return 1;
    } 
	else {
           return n * CalculateFactorial(n - 1);
       }
 }

}
