
public class Edge implements Comparable<Edge>{

	private int sourceVertex;
	private int destVertex;
	
	private double weight;
	
	public Edge(int vertex1, int vertex2, double weight) {
		this.sourceVertex = vertex1;
		this.destVertex = vertex2;
		this.weight = weight;
	}
	
	public int getFrom() {
		return this.sourceVertex;
	}
	
	public int getTo() {
		return this.destVertex;
	}
	
	public double getWeight() {
		return this.weight;
	}
	
	public String toString() {
		return "(" + sourceVertex + "--> " + destVertex + "): " + weight;
	}
	

	@Override
	// make sure out priority queue sorts from least to greatest based on edge weights
	public int compareTo(Edge otherEdge) {
		
		if(weight < otherEdge.weight) {
			return  -1;
		}
		else if(weight > otherEdge.weight) {
			return 1;
		}
		else {
			return 0;
		}
		
	}
	
}
