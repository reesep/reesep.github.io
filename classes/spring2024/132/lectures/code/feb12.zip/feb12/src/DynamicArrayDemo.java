
public class DynamicArrayDemo {

	public static void main(String[] args) {
		
		
		DynamicArray array = new DynamicArray();
		array.add("Reese");
		array.add("Susan");
		array.add("Spencer");
		
		array.print();
	}

}
