import java.util.Arrays;

public class DynamicArray{

	
	private String[] array;
	
	public DynamicArray() {
		this.array = new String[0];
	}
	
	public void add(String newName) {
		
		String[] newArray = new String[array.length +1];
		
		//copy everything over from old to new
		for(int i = 0; i < array.length; i++) {
			newArray[i] = array[i];
		}
		//insert new name
		newArray[array.length] = newName;
		
		//update my pointer
		array = newArray;
		
	}
	
	// [ Reese Susan Spencer ] 
	public void print() {
		
		String ans = "[ ";
		for(String s: array) {
			ans += s + " ";
		}
		
		System.out.println(ans + "]");
	}
	
	
	
}
