
public interface RegularPolygon {
	
	public double area();
	
	public double perimeter();
		
}
