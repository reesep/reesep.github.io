import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		
		
		
		
		
		
		ArrayList<String> arr = new ArrayList<String>();
		
		arr.add("Reese");
		arr.add("Susan");
		arr.add("Spencer");
		
		arr.remove(0);
		
		System.out.println(arr);
		
		System.out.println(arr.get(1));
		

	}

}
