
public class VideoGame {

	
	private String name;
	private char rating;
	
	public VideoGame(String n, char r) {
		this.name = n;
		this.rating = r;
	}
	
	public String getName() {
		return this.name;
	}
	
	public char getRating() {
		return this.rating;
	}
	
}
