
public class HappyBirthdayDemo {

	public static void main(String[] args) {
		
		HappyBirthday.sing("John");

	}

}
