import java.util.LinkedList;

public class ShortestPath {

	public void computeShortestPath(WeightedDirectedGraph graph, int start) {
		//Dijkstra's Algorithm
		
	}

	public LinkedList<Edge> getPathTo(int destination) {
		
		return null;
	}
	
	

}
