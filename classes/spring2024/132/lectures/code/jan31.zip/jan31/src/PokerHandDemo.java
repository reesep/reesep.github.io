
public class PokerHandDemo {

	public static void main(String[] args) {
		
		
		PokerHand ph = new PokerHand(new Card("Hearts",4), new Card("Diamonds",4), new Card("Spades",4));

		//ph.checkHand();		
	}

}
