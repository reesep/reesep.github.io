
public class PokerHand {

	private Card[] hand;
	
	public PokerHand(Card card1, Card card2, Card card3) {
		
		hand[0] = card1;
		hand[1] = card2;
		hand[2] = card3;
		
	}
	
	
	
}
