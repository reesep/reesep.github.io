import java.util.Collections;
import java.util.LinkedList;

public class Lab12Demo {

	public static void main(String[] args) {
		
		LinkedList<Item> items = new LinkedList<Item>();
		double weight_capacity = 35;  // capacity of the knapsack
		
		// Add items. Format: Name, Value, Weight
		items.add(new Item("Gold Bar",100,20));
		items.add(new Item("Emerald Bar",40,5));
		items.add(new Item("Ruby Bar",13,10));
		items.add(new Item("Silver Bar",88,12));
		items.add(new Item("Sapphire Bar",52,8));
		items.add(new Item("Copper Bar",13,8));
		items.add(new Item("Quartz Bar",1,12));
		items.add(new Item("Pearl",20,1));
					
		// TO DO. Your code for the knapsack problem will go here.

	}

}