
public class FileTreeDemo {

	public static void main(String[] args) {
		
		FileTreeManager files = new FileTreeManager();
		//files.run();
		files.test();
	}

}
