
public class Edge implements Comparable<Edge> {

	// Edge class now also keeps track of the city names
	// You shouldn't need to modify anything here
    private int vertex1;
    private String vertex1Name;
    private int vertex2;
    private String vertex2Name;
    private double weight;

    public Edge(int vertex1, String name1, int vertex2, String name2, double weight) {
        this.vertex1 = vertex1;
        this.vertex1Name = name1;
        this.vertex2 = vertex2;
        this.vertex2Name = name2;
        this.weight = weight;
    }

    public int[] getVertices() {
        return new int[]{vertex1, vertex2};
    }

    public double getWeight() {
        return weight;
    }
    
    @Override
    public String toString() {
        return "(" + vertex1Name + "," + vertex2Name + "): " + weight;
    }
    
    @Override
    public int hashCode() {
        return vertex1 + vertex2;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Edge)) {
            return false;
        }
        
        Edge otherEdge = (Edge) obj;
        
        if ((vertex1 == otherEdge.vertex1 && vertex2 == otherEdge.vertex2) || (vertex1 == otherEdge.vertex2 && vertex2 == otherEdge.vertex1)) {
            return true;
        }
        return false;
    }

    @Override
    public int compareTo(Edge otherEdge) {
        if (weight < otherEdge.weight) {
            return -1;
        } else if (weight > otherEdge.weight) {
            return 1;
        } else {
            return 0;
        }
    }

    // Instead of getTo() and getFrom(), we change it to getOther() since we have undirected edges
	public int getOther(int current) {
		if(current == vertex1) {
			return vertex2;
		}
		else {
			return vertex1;
		}
	}


}