import java.util.LinkedList;
import java.util.PriorityQueue;

public class ShortestPath {

	
	private double[] distance;
    private Edge[] previous;
	
    public void computeShortestPath(WeightedGraph graph, int s, int e) {
    	// TO DO: Part 5
    	// Write code for Dijkstra’s Algorithm here. After you finish Dijkstra’s Algorithm, 
    	//   you will need to query the distance and previous data structures using the getPathTo() method (already written for you)
    	
    	
    }
    
    public double distanceTo(int vertex) {
        return distance[vertex];
    }

    public boolean hasPathTo(int vertex) {
        return distance[vertex] < Double.POSITIVE_INFINITY;
    }

    public LinkedList<Edge> getPathTo(int vertex) {   
        if (!hasPathTo(vertex)) {
            return null;
        } else {
            LinkedList<Edge> path = new LinkedList<>();
            Edge edge = previous[vertex];
            while(edge != null) {
            	path.addFirst(edge);
            	vertex = edge.getOther(vertex);
            	edge = previous[vertex];
            }
            
            return path;
        }
    }

    
}
