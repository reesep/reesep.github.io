import java.io.FileReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Scanner;

public class WeightedGraph {

	private LinkedList<Edge>[] adjacencyList;
    private HashSet<Edge> edges;
    
    private HashMap<Integer, String> vertexToAirport; //part 1
    
    public WeightedGraph(int numVertices) {
        adjacencyList = new LinkedList[numVertices];

        for (int i = 0; i < adjacencyList.length; i++) {
            adjacencyList[i] = new LinkedList<>();
        }
        
        edges = new HashSet<>();
        
        vertexToAirport = new HashMap<Integer, String>();
        
        loadAirportInfo(); // part 1
        loadEdgeInfo(); // part 2
   
    }

    public void loadAirportInfo() {
    	// TO DO: Part 1. Read in airports.txt, and add key-value pairs into vertexToAirport HashMap
		
	}

	public void loadEdgeInfo() {
		// TO DO: Part 2. Read in edges.txt, and add edges into graph using the addEdge() method
		
	}
	
	public void findMostConnections() {
		// TO DO: Part 3. Find vertex with highest degree
		
	}
	
	// Given an integer vertex #, returns the city for that integer vertex
	public String getAirportName(int vertex) {
		return vertexToAirport.get(vertex);
	}
	
	// Given a string (city), returns the integer label in our graph for that city
	public int getVertexNumber(String end) {
		
		for(Integer key: vertexToAirport.keySet()) {
			if(vertexToAirport.get(key).equals(end)) {
				return key;
			}
		}
		return -1;
		
	}
	
	public int getNumVertices() {
        return adjacencyList.length;
    }

    public int getNumEdges() {
        return edges.size();
    }

    public LinkedList<Edge> getAdjacencyEdges(int vertex){
    	return adjacencyList[vertex];
    }
    
    // Adds a new edge to graph
    public void addEdge(int vertex1, String name1, int vertex2, String name2, double weight) {
        Edge edge = new Edge(vertex1, name1, vertex2, name2, weight);
        if (edges.add(edge)) {
        	adjacencyList[vertex1].add(edge);
        	adjacencyList[vertex2].add(edge);
        }
    }

    public HashSet<Edge> getEdges() {
        return edges;
    }

	public void printGraph() {
		for(LinkedList<Edge> each: adjacencyList) {
			System.out.println(each);
		}
		
	}
    

	
	
	
}
