import java.util.LinkedList;
import java.util.Scanner;

public class Program3Demo {

	public static void main(String[] args) {
		
		WeightedGraph graph = new WeightedGraph(14);
		
		// Uncomment the line below after you have done part 1 and 2, and verify your graph was built correctly
		//graph.printGraph();
		Scanner in = new Scanner(System.in);
		
		int choice = 0;
		while(choice != 4) {
			
			System.out.println("1. Find city with most connections");
			System.out.println("2. Print MST of Graph");
			System.out.println("3. Find shortest path between cities");
			System.out.println("4. Exit");
			
			System.out.println("Your choice? ");
			choice = in.nextInt();
			if(choice == 1) {
				//Part 3
				graph.findMostConnections();
			}
			else if(choice == 2) {
				// Part 4
				MST mst = new MST();
				mst.computeMST(graph);
			}
			else if(choice == 3) {
				// Part 5
				//Get the starting city, and end city
				ShortestPath sp = new ShortestPath();
				System.out.println("What is the starting city? (ex. BZN, NYC, MSP)");
				String start = in.next();
				System.out.println("What is the destination city? (ex. BZN, NYC, MSP)");
				String end = in.next();
				
				// Our graph has integer vertices, so convert city name to it's integer label
				int start_vertex = graph.getVertexNumber(start);
				int end_vertex = graph.getVertexNumber(end);
				
			    sp.computeShortestPath(graph, start_vertex, end_vertex);
			        
			}
		}
		in.close();


	}

}
