
public class UndirectedGraphDemo {

	public static void main(String[] args) {
		
		
		UndirectedGraph graph = new UndirectedGraph(6);

		graph.addEdge(0,2);
		graph.addEdge(0,1);
		graph.addEdge(1,2);
		graph.addEdge(1,3);
		graph.addEdge(2,4);
		graph.addEdge(3,4);
		graph.addEdge(3,5);
		graph.addEdge(4,5);
		
		System.out.println(graph.isTherePath(0,5));
		//graph.depthFirst(0);
		
		
		/*
		graph.printGraph();
		
		graph.removeEdge(1,3);
		System.out.println();
		graph.printGraph();
		System.out.println(graph.getNeighbors(4));
		System.out.println(graph.getDegree(4));
		
		System.out.println(graph.getEdges());
		System.out.println(graph.getVertices());
		*/
		
		/*
		UndirectedGraphHashMap graph = new UndirectedGraphHashMap();
		
		graph.addVertex("Reese");
		graph.addVertex("Susan");
		graph.addVertex("Brian");
		graph.addVertex("James");
		
		graph.addEdge("Reese", "James");
		graph.addEdge("Reese", "Brian");
		graph.addEdge("Reese", "Susan");
		graph.addEdge("Brian", "James");
		
		graph.printGraph();
		*/
	}

}
