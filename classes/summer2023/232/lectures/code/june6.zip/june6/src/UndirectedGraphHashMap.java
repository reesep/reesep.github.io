import java.util.HashMap;
import java.util.LinkedList;

public class UndirectedGraphHashMap {

	private HashMap<String, LinkedList<String>> adjList;
	
	// Reese: <James, Brian, Susan>
	// James: <Reese, Brian>
	// Brian: <James, Reese>
	// Susan: <Reese>
	
	public UndirectedGraphHashMap() {
		adjList = new HashMap<String, LinkedList<String>>();
	}
	
	public void addVertex(String newName) {
		//add new key-value pair (linked list will be empty for now)
		adjList.put(newName, new LinkedList<String>());
	}
	
	public void addEdge(String name1, String name2) {
		LinkedList<String> neighbors = adjList.get(name1);
		neighbors.add(name2);
		adjList.put(name1, neighbors);
		
		neighbors = adjList.get(name2);
		neighbors.add(name1);
		adjList.put(name2, neighbors);
	}
	
	public void printGraph() {
		
		for(String key: adjList.keySet()) {
			System.out.println(key + ": " + adjList.get(key));
		}
		
	}
	
	public void removeVertex(String name) {
		//remove key
		// do for loop and remove all instances of 'name'
	}
	
	public void removeEdge(String name1, String name2) {
		// Remove name1 from name2's adjlist
		// remove name2 from name1's adjlist
	}
	
}
