
public class StudentDatabaseDemo {

	public static void main(String[] args) {
		
		StudentDatabaseHashTable database = new StudentDatabaseHashTable();

		database.addStudent("Joe",12345,"Computer Science",4.0);
		database.addStudent("Sally",99899,"Math",4.0);
		database.addStudent("Sean",11111,"History",3.9);
		database.addStudent("Reese",22222,"Computer Science",3.8);
		database.addStudent("Susan",33333,"Nursing",4.0);
		database.addStudent("John",44444,"Biology",2.1);
		database.addStudent("Anne",55555,"Computer Science",3.9);
		database.addStudent("hunter",77777,"Math",4.0);
		database.addStudent("Laura",88888,"Biology",4.0);
		database.addStudent("Shane",99999,"Math",2.7);
		database.addStudent("Kyle",00000,"Math",2.7);
		
		database.gradeInfo();
		//database.studentsByMajor();
		//database.printDatabase();
		
		
		
		
	}

}
