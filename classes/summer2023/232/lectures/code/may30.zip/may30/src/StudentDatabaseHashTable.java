import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import java.util.List;

public class StudentDatabaseHashTable {

	private HashMap<Integer, Student> database;
	private int size;
	private Set<Integer> keySpace; //holds keys of dictionary
	
	public StudentDatabaseHashTable() {
		this.database = new HashMap<Integer, Student>();
		this.size = 0;
		this.keySpace = new HashSet<Integer>();
	}
	
	public void addStudent(String name, int id, String major, double gpa) {
		Student s = new Student(name, id, major, gpa);
		this.database.put(id, s); //put key-value pair into hashmap
		this.keySpace.add(id);
		this.size++;
	}
	
	//this is now unused
	public int hash(int key) {
		return key % 100;
	}
	
	//this is now unused
	public int getArraySpot(int id) {
		return id % 100;
	}
	
	public void printDatabase() {
		for(Student s: this.database.values()) {
			s.printStudent();
		}
	}
	
	
	public void removeStudent(int student_id) {
		this.database.remove(student_id);
		this.keySpace.remove(student_id);
		this.size--;
	}
	
	public void removeStudent(String name) {
		
		for(Integer i: this.keySpace) {
			Student s = this.database.get(i);
			if(s.getName().equals(name)) {
				this.database.remove(s.getID());
				this.keySpace.remove(s.getID());
				this.size--;
				break;
			}
		}
		
	}
	
	
	public Student getStudent(int student_id) {
		return this.database.get(student_id);
	}

	public int getSize() {
		return this.size;
	}
	
	public void studentsByMajor() {
		
		//Desired Output
		// Define a new HashMap <String, Int>
		// Computer Science: 3
		// Math: 2
		// History: 1
		// Nursing: 1
		// Biology: 1
		
		HashMap<String, Integer> freq = new HashMap<String, Integer>();
		for(Student s: this.database.values()) {
			
			if( !freq.containsKey(s.getMajor())){
				freq.put(s.getMajor(), 1);
			}
			else {
				freq.put(s.getMajor(), freq.get(s.getMajor()) + 1);
			}
		}
		for(String m: freq.keySet()) {
			System.out.println(m + ": " + freq.get(m));
		}
	
	}
	
	public void gradeInfo() {
		
		// 4.0 : [Joe, Sally, Susan, Hunter, Laura]
		// 3.9 : [Sean, Ann]
		// 3.8 : [Reese]
		// 2.5 : [John]
		
		HashMap<Double, HashSet<String>> grades = new HashMap<Double, HashSet<String>>();
		
		for(Student s: this.database.values()) {
			
			Double each_gpa = s.getGPA();
			if( !grades.containsKey(each_gpa)) {
				//insert a new key-value pair
				grades.put(each_gpa, new HashSet<String>());
			}
			HashSet<String> old_set = grades.get(each_gpa);
			old_set.add(s.getName());
			grades.put(each_gpa, old_set);
		}
		Set<Double> keySet = grades.keySet();
		//Cannot .sort on a Set, we have to convert to a List
		List<Double> keyList = new ArrayList<>(keySet);
		Collections.sort(keyList, Collections.reverseOrder());
		for(Double d: keyList) {
			System.out.println("Students that achieved a GPA of " + d + ": " + String.join(", ",grades.get(d)));
		}
		
	}
	
	
	
	
	
}

