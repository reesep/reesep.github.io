import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;

public class StacksAndQueuesDemo {

	public static void main(String[] args) {
		
		Stack<String> stack = new Stack<String>();

		stack.push("One");
		stack.push("Two");
		stack.push("Three");
		
		System.out.println(stack.pop());
		System.out.println(stack.peek());
		
		Queue<String> queue = new LinkedList<String>();
		
		queue.add("Susan");
		queue.add("Reese");
		queue.add("John");
		
		System.out.println(queue.remove());
		System.out.println(queue.remove());
		System.out.println(queue.remove());
		
	}

}
