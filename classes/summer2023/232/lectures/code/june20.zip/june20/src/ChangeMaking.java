
public class ChangeMaking {

	public static void main(String[] args) {
		
		int[] d = {1, 5, 10, 18, 25};
		int k = 37;
		
		int[] dp = new int[k + 1];
		for(int i = 0; i < dp.length; i++) {
			dp[i] = -1;
		}
		
		int solution = minCoin(d, k, dp);
		System.out.println(solution);
		
	}
	
	public static int minCoin(int[] d, int k, int[] dp) {
		if(k == 0) {
			return 0;
		}
		else if(dp[k] != -1) {
			return dp[k];
		}
		else {
			
			int a = Integer.MAX_VALUE;
			int min = Integer.MAX_VALUE;
			
			for(int i = 0; i < d.length; i++) {
				
				if( k - d[i] >= 0) {
					a = minCoin(d, k - d[i], dp);
					
				}
				if(a < min) {
					min = a + 1;
					
				}
				
			}
			
			dp[k] = min;
			return min;
			
			
		}
	}

}
