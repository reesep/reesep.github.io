
public class StudentDatabaseDemo {

	public static void main(String[] args) {
		
		StudentDatabase database = new StudentDatabase();
		database.addStudent("Joe", 12345, 3.5);
		database.addStudent("Sally", 44566, 2.1);
		database.addStudent("John", 98765, 4.8);
		database.addStudent("Susan", 22222, 2.8);
		
		database.printDatabase();
		System.out.println();
		
		StudentDatabaseLinkedList databaseLL = new StudentDatabaseLinkedList();
		databaseLL.addStudent("Joe", 12345, 3.5);
		databaseLL.addStudent("Sally", 44566, 2.1);
		databaseLL.addStudent("John", 98765, 4.8);
		databaseLL.addStudent("Susan", 22222, 2.8);
		
		databaseLL.printDatabase();
		
		database.getStudentByName("Joe");
		databaseLL.getStudentByName("Joe");
		
		database.removeStudent("John");
		databaseLL.removeStudent("John");
		
		database.printDatabase();
		databaseLL.printDatabase();
	}

}
