import java.util.LinkedList;

public class StudentDatabaseLinkedList {

	private LinkedList<Student> studentDatabase;
	private int count;
	
	public StudentDatabaseLinkedList() {
		this.studentDatabase = new LinkedList<Student>();
		this.count = 0;
	}
	
	public void addStudent(String studentName, int studentID, double studentGPA) {
		Student s = new Student(studentName, studentID, studentGPA);
		this.studentDatabase.add(s);
	}
	
	public void printDatabase() {
		
		for(Student s: this.studentDatabase) {
			System.out.println(s.getName() + " " + s.getID() + " " + s.getGPA());
		}
		
	}
	
	public void getStudentByName(String searchName) {
		//TO DO:
		
	}
	
	public void removeStudent(String searchName) {
		//TO DO:
	}
	
}
