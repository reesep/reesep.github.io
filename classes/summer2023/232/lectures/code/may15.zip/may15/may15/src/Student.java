
// This is a comment
public class Student {

	//Instance Fields
	private String name;
	private int student_id;
	private double gpa;
	
	//Methods
	public Student(String in_name, int in_id, double in_gpa) {
		this.name = in_name;
		this.student_id = in_id;
		this.gpa = in_gpa;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getID() {
		return this.student_id;
	}
	
	public double getGPA() {
		return this.gpa;
	}
	
}
