
public class StudentDatabase {

	private Student[] studentDatabase;
	private int count;
	
	public StudentDatabase() {
		this.studentDatabase = new Student[0];
		this.count = 0;
	}

	public void addStudent(String studentName, int studentID, double studentGPA) {
		
		Student s = new Student(studentName, studentID, studentGPA);
		Student[] tempDatabase = new Student[this.studentDatabase.length+1];
		for(int i =0; i < studentDatabase.length; i++) {
			tempDatabase[i] = studentDatabase[i];
		}
		tempDatabase[studentDatabase.length] = s;
		studentDatabase = tempDatabase;
		this.count++;
	}
	
	public void printDatabase() {
		
		for(Student s: this.studentDatabase) {
			System.out.println(s.getName() + " " + s.getID() + " " + s.getGPA());
		}
		
	}
	
	public double findHighestGPA() {
		
		double highest_so_far = 0;
		for(Student s: this.studentDatabase) {
			
			if(s.getGPA() > highest_so_far) {
				highest_so_far = s.getGPA();
			}
			
		}
		return highest_so_far;
	}
	
	public void getStudentByName(String searchName) {
		//TO DO:
		
	}
	
	public void removeStudent(String searchName) {
		//TO DO:
	}
	
}
