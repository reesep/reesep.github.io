
public class StudentDatabaseDemo {

	public static void main(String[] args) {
		
		Student student1 = new Student("Joe", 12345, 3.5);
		
		System.out.println(student1.getName());
		System.out.println(student1.getID());
		System.out.println(student1.getGPA());

		Student student2 = new Student("Sally", 55677, 2.1);
		
		System.out.println(student2.getName());
		System.out.println(student2.getID());
		System.out.println(student2.getGPA());
	}

}
