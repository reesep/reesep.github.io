
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;


public class DocumentChecker {

	
	private HashMap<String,Integer> wordCount;
	private HashSet<String> words;
	
	
	public DocumentChecker(String filename) {
		wordCount = loadHashMap(filename);
		words = loadHashSet();
	}
	
	public HashMap<String,Integer> loadHashMap(String filename){
		
	}
	
	public HashSet<String> loadHashSet(){
		
	}
	
	
	public void spellcheck() {

	}
	
	public void wordCountAlphabetically() {
		
	}

	
	public void wordCountByFrequency() {
		 //hi: 2
		 //2: [test, spell, hi]
		
		HashMap<Integer, HashSet<String>> wordsPerCount = new HashMap<Integer, HashSet<String>>();
		for(String s: this.wordCount.keySet()) {
			int count = wordCount.get(s);
			if(!wordsPerCount.containsKey(count)) {
				wordsPerCount.put(count, new HashSet<String>());
			}
			HashSet<String> old_set = wordsPerCount.get(count);
			old_set.add(s);
			wordsPerCount.put(count, old_set);	
		}
		//Sort the keys
		Set<Integer> keySet = wordsPerCount.keySet();
		//Cannot .sort on a Set, we have to convert to a List
		List<Integer> sortedKeyList = new ArrayList<>(keySet);
		Collections.sort(sortedKeyList, Collections.reverseOrder());
	
		for(Integer i: sortedKeyList) {
			System.out.println(i + ": " + String.join(", ",wordsPerCount.get(i)));
		}
		System.out.println();
	}
	
	
	
	
	
	
	
	
}
