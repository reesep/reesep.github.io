
import java.io.FileReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class AnimalTree {

    private Node root;

    public AnimalTree() {
        loadBST();  // read file and construct tree
    }

    
    public void identify() {
    	
    	// TO DO: PART 2. Use tree to identify animals
    	
    }
	

    public void loadBST() {
        try {
        	FileReader file = new FileReader("tree.txt");
        	Scanner inFile = new Scanner(file);
        	
        	while( inFile.hasNext()) {
        		insert(inFile.nextLine());
        	}
        	inFile.close();
     
        }
    	catch(Exception e) {
    		System.out.println("Error reading from file.");
    	}
    	
    }

 
    public void insert(String newNode) {
      
    	//Parse line from file
    	int index = newNode.indexOf(",");
    	int nodeNum = Integer.parseInt(newNode.substring(0, index));
    	String prompt = newNode.substring(index+1);
    	
    	//insert node into BST
    	if(root == null) {
    		root = new Node(prompt, nodeNum);
    	}
    	else {
    		Node currentNode = root;
    		boolean placed = false;
    		while(!placed) {
    			if(nodeNum < currentNode.getNodeNum()) {
    				if(currentNode.getLeft() == null) {
    					currentNode.setLeft(new Node(prompt, nodeNum));
    					currentNode.getLeft().setParent(currentNode);
    					placed = true;
    				}
    				else {
    					currentNode = currentNode.getLeft();
    				}
    			}
    			else { // if nodeNum > currentNode.getNodeNum()
    				if(currentNode.getRight() == null) {
    					currentNode.setRight(new Node(prompt, nodeNum));
    					currentNode.getRight().setParent(currentNode);
    					placed = true;
    				}
    				else {
    					currentNode = currentNode.getRight();
    				}
    			}
    		}
    	}
    	
    }
    
    // Performs breadth first search and prints out tree
    public void breadthFirst() {
		Queue<Node> queue = new LinkedList<>();
		if(root != null) {
			queue.add(root);
			while(!queue.isEmpty()) {
				
				Node node = queue.remove();
				
				System.out.println(node.getPrompt() + " " + node.getNodeNum());
				
				if (node.getLeft() != null) {
                    queue.add(node.getLeft());
                }
                if (node.getRight() != null) {
                    queue.add(node.getRight());
                }
			}
		}
	}
	
}