import java.util.LinkedList;

public class StudentDatabaseSC {

	private LinkedList<Student>[] database;
	
	public StudentDatabaseSC(int size) {
		database = new LinkedList[size];
	}
	
	public int hash(int student_id) {
		return student_id % database.length;
	}
	
	public void addStudent(String name, int id, String major, double gpa) {
		Student newStudent = new Student(name, id, major, gpa);
		
		int arrayIndex = hash(id);
		if(database[arrayIndex] == null) {
			database[arrayIndex] = new LinkedList<Student>();
		}
		database[arrayIndex].add(newStudent);
	}
	
	public void printDatabase() {
		
		for(int i = 0; i < database.length; i++) {
			
			if(database[i] != null) {
				if(!database[i].isEmpty()) {
					String studentInfo = "";
					for(Student each: database[i]) {
						studentInfo += each.getName() + "(" + each.getID() + ")"+ ", ";
					}
					System.out.println(studentInfo.substring(0, studentInfo.length()-2));
				}
			}
			
		}
		
	}
	
	public void getStudentInfo(int student_id) {
		boolean found = false;
		int arrayIndex = hash(student_id);
		if(database[arrayIndex] == null) {
			System.out.println("Student not found: " + student_id);
		}
		else {
			for(Student each: database[arrayIndex]) {
				if(each.getID() == student_id) {
					each.printStudent();
					found = true;
				}
			}
			if(found == false) {
				System.out.println("Student not found: " + student_id);
			}
		}
			
	}
	
	public void remove(int student_id) {
		boolean found = false;
		int arrayIndex = hash(student_id);
		if(database[arrayIndex] == null) {
			System.out.println("Student not found: " + student_id);
		}
		else {
			
			for(Student each: database[arrayIndex]) {
				if(each.getID() == student_id) {
					database[arrayIndex].remove(each);
					found = true;
				}	
			}
			if(found == false) {
				System.out.println("Student not found: " + student_id);
			}
			
			
		}
		
	}
	
	
}
