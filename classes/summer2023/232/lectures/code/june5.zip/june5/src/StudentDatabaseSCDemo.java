
public class StudentDatabaseSCDemo {

	public static void main(String[] args) {
	
		// 97 is a prime number, help reduce collisions
		StudentDatabaseSC database = new StudentDatabaseSC(97);
		
		database.addStudent("Joe",12345,"Computer Science",4.0);
		database.addStudent("Sally",97097,"Math",4.0);
		database.addStudent("Sean",11145,"History",3.9);
		database.addStudent("Reese",22245,"Computer Science",3.8);
		database.addStudent("Susan",33333,"Nursing",4.0);
		database.addStudent("Collision",97000,"Evil",4.0);

		database.printDatabase();
		
		//database.getStudentInfo(77777);
		//database.remove(77777);
		//System.out.println();
		//database.printDatabase();
		
	}

}
