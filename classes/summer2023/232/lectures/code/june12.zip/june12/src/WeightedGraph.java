import java.util.HashSet;
import java.util.LinkedList;

public class WeightedGraph {

	private LinkedList<Edge>[] adjList;
	private HashSet<Edge> edges;
	
	public WeightedGraph(int numVertices) {
		
		adjList = new LinkedList[numVertices];
		
		for(int i = 0; i < adjList.length;i++) {
			adjList[i] = new LinkedList<>();
		}
		
		edges = new HashSet<>();
		
	}
	
	public int getNumVertices() {
		return adjList.length;
	}
	
	public int getNumEdges() {
		return edges.size();
	}
	
	public HashSet<Edge> getEdges(){
		return edges;
	}
	
	public void addEdge(int vertex1, int vertex2, double weight) {
		Edge edge = new Edge(vertex1, vertex2, weight);
		if(edges.add(edge)) {
			adjList[vertex1].add(edge);
			adjList[vertex2].add(edge);
		}
	}
	
	
}
