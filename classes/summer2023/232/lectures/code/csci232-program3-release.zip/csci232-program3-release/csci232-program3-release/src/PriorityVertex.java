
public class PriorityVertex implements Comparable<PriorityVertex>{
	 // You shouldn't need to modify anything here.
	 public int vertex;
     public double distanceFromSource;

     public PriorityVertex(int vertex, double distanceFromSource) {
         this.vertex = vertex;
         this.distanceFromSource = distanceFromSource;
     }

     @Override
     public int compareTo(PriorityVertex other) {
         return Double.valueOf(distanceFromSource).compareTo(other.distanceFromSource);
     }

     @Override
     public boolean equals(Object obj) {
         if (!(obj instanceof PriorityVertex)) {
             return false;
         }

         PriorityVertex other = (PriorityVertex) obj;
         
         if (vertex == other.vertex) {
             return true;
         }
         
         return false;
     }
	
}
