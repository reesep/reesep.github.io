import java.util.LinkedList;
import java.util.PriorityQueue;

public class ShortestPath {

	
	private double[] distance;
    private Edge[] previous;
	
    public void computeShortestPath(WeightedGraph graph, int s, int e) {
    	
    	distance = new double[graph.getNumVertices()];
    	for(int vertex = 0; vertex < graph.getNumVertices(); vertex++) {
    		distance[vertex] = Double.POSITIVE_INFINITY;
    	}
    	distance[s] = 0;
    	
    	previous = new Edge[graph.getNumVertices()];
    	
    	PriorityQueue<PriorityVertex> visitQueue = new PriorityQueue<>();
    	visitQueue.add(new PriorityVertex(s,0));
    	
    	while(!visitQueue.isEmpty()) {
    		
    		PriorityVertex vertex = visitQueue.poll();
    		for(Edge edge: graph.getAdjacencyEdges(vertex.vertex)) {
    			int current = vertex.vertex;
    			int neighbor = edge.getOther(current);
    			
    			if( distance[current] + edge.getWeight() < distance[neighbor]) {
    				
    				distance[neighbor] = distance[current] + edge.getWeight();
    				previous[neighbor] = edge;
    				
    				visitQueue.remove(new PriorityVertex(neighbor,0));
    				visitQueue.add(new PriorityVertex(neighbor,distance[neighbor]));
    				
    			}
    			
    			
    		}
    		
    	} // end of while loop (End of dijkstras)
    	
    	double totalWeight = 0;
    	LinkedList<Edge> solution = getPathTo(e);
    	for(Edge edge: solution) {
    		totalWeight += edge.getWeight();
    		System.out.println(edge);
    	}
    	System.out.println("The total cost to go from " + graph.getAirportName(s) + " to " + graph.getAirportName(e) + ": " + totalWeight);
    	
    	
    }
    
    public double distanceTo(int vertex) {
        return distance[vertex];
    }

    public boolean hasPathTo(int vertex) {
        return distance[vertex] < Double.POSITIVE_INFINITY;
    }

    public LinkedList<Edge> getPathTo(int vertex) {   
        if (!hasPathTo(vertex)) {
            return null;
        } else {
            LinkedList<Edge> path = new LinkedList<>();
            Edge edge = previous[vertex];
            while(edge != null) {
            	path.addFirst(edge);
            	vertex = edge.getOther(vertex);
            	edge = previous[vertex];
            }
            
            return path;
        }
    }

    
}
