import java.util.HashSet;
import java.util.PriorityQueue;

public class MST {

	public void computeMST(WeightedGraph graph) {
		//TO DO: Part 4. Write code for Kruskal's algorithm here.
		
		
	}
	
	
}
