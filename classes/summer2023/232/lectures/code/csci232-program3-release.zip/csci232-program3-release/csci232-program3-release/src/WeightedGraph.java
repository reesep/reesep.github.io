import java.io.FileReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Scanner;

public class WeightedGraph {

	private LinkedList<Edge>[] adjacencyList;
    private HashSet<Edge> edges;
    
    private HashMap<Integer, String> vertexToAirport; //part 1
    
    public WeightedGraph(int numVertices) {
        adjacencyList = new LinkedList[numVertices];

        for (int i = 0; i < adjacencyList.length; i++) {
            adjacencyList[i] = new LinkedList<>();
        }
        
        edges = new HashSet<>();
        
        vertexToAirport = new HashMap<Integer, String>();
        
        loadAirportInfo(); // part 1
        loadEdgeInfo(); // part 2
   
    }

    public void loadAirportInfo() {
    	try {
    		FileReader file = new FileReader("airports.txt");
    		Scanner in = new Scanner(file);
    		while(in.hasNext()) {
    			String line = in.nextLine();
    			String[] line_splitted = line.split(",");
    			// .replaceAll("\\p{C}", "") removes the invisible zero width space character.
    			int vertex_number = Integer.parseInt(line_splitted[0].replaceAll("\\p{C}", ""));
    			String city_name = line_splitted[1];
    			vertexToAirport.put(vertex_number, city_name);
    		}
    		in.close();
    	}catch(Exception e) {
    		System.out.println(e);
    		System.out.println("Error");
    	}
    	
		
	}

	public void loadEdgeInfo() {
		try {
    		FileReader file = new FileReader("edges.txt");
    		Scanner in = new Scanner(file);
    		while(in.hasNext()) {
    			String line = in.nextLine();
    			String[] line_splitted = line.split(",");
    			
    			int vertex1 = Integer.parseInt(line_splitted[0].replaceAll("\\p{C}", ""));
    			int vertex2 = Integer.parseInt(line_splitted[1]);
    			String city1 = vertexToAirport.get(vertex1);
    			String city2 = vertexToAirport.get(vertex2);
    			int weight = Integer.parseInt(line_splitted[2]);
    			addEdge(vertex1, city1, vertex2, city2, weight);
    		}
    		in.close();
    	}catch(Exception e) {
    		System.out.println(e);
    		System.out.println("Error");
    	}
	}
	
	public void findMostConnections() {
		// TO DO: Part 3. Find vertex with highest degree
		
	}
	
	// Given an integer vertex #, returns the city for that integer vertex
	public String getAirportName(int vertex) {
		return vertexToAirport.get(vertex);
	}
	
	// Given a string (city), returns the integer label in our graph for that city
	public int getVertexNumber(String end) {
		
		for(Integer key: vertexToAirport.keySet()) {
			if(vertexToAirport.get(key).equals(end)) {
				return key;
			}
		}
		return -1;
		
	}
	
	public int getNumVertices() {
        return adjacencyList.length;
    }

    public int getNumEdges() {
        return edges.size();
    }

    public LinkedList<Edge> getAdjacencyEdges(int vertex){
    	return adjacencyList[vertex];
    }
    
    // Adds a new edge to graph
    public void addEdge(int vertex1, String name1, int vertex2, String name2, double weight) {
        Edge edge = new Edge(vertex1, name1, vertex2, name2, weight);
        if (edges.add(edge)) {
        	adjacencyList[vertex1].add(edge);
        	adjacencyList[vertex2].add(edge);
        }
    }

    public HashSet<Edge> getEdges() {
        return edges;
    }

	public void printGraph() {
		for(LinkedList<Edge> each: adjacencyList) {
			System.out.println(each);
		}
		
	}
    

	
	
	
}
