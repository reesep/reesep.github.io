
public class Edge implements Comparable<Edge>{

	private int sourceVertex;
	private int destVertex;
	private double weight;
	
	public Edge(int vertex1, int vertex2, double weight) {
		this.sourceVertex = vertex1;
		this.destVertex = vertex2;
		this.weight = weight;
	}
	
	public int getFrom() {
		return sourceVertex;
	}
	
	public int getTo() {
		return destVertex;
	}
	
	public double getWeight() {
		return weight;
	}
	
	@Override
	public int compareTo(Edge otherEdge) {
		// help priority queue sort edges in terms of weight
		if(weight < otherEdge.weight) {
			return -1;
		}
		else if(weight > otherEdge.weight) {
			return 1;
		}
		else {
			return 0;
		}	
	}
	
	
	@Override
	public String toString() {
		return "(" + sourceVertex + "-->" + destVertex + "): " + weight;
	}
	
	
	
}
