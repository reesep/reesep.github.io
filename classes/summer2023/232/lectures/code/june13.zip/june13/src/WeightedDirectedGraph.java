import java.util.HashSet;
import java.util.LinkedList;

public class WeightedDirectedGraph {

	private LinkedList<Edge>[] adjList;
	private HashSet<Edge> edges;
	
	public WeightedDirectedGraph(int numVertices) {
		
		adjList = new LinkedList[numVertices];
		
		for(int i = 0; i < adjList.length;i++) {
			adjList[i] = new LinkedList<>();
		}
		
		edges = new HashSet<>();
		
	}
	
	public int getNumVertices() {
		return adjList.length;
	}
	
	public int getNumEdges() {
		return edges.size();
	}
	
	public LinkedList<Edge> getAdjacencyEdges(int vertex){
		return adjList[vertex];
	}
	
	public HashSet<Edge> getEdges(){
		return edges;
	}
	
	public void addEdge(int sourceVertex, int destVertex, double weight) {
		Edge edge = new Edge(sourceVertex, destVertex, weight);
		if(edges.add(edge)) {
			adjList[sourceVertex].add(edge);
		}
	}
	
	
}
