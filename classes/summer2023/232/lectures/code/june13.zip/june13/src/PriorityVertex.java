
public class PriorityVertex implements Comparable<PriorityVertex>{

	
	private int vertex;
	private double distanceFromSource;
	
	public PriorityVertex(int vertex, double d) {
		this.vertex = vertex;
		this.distanceFromSource = d;
	}
	
	public int getVertex() {
		return vertex;
	}
	
	public double getDistance() {
		return distanceFromSource;
	}
	
	@Override
	public int compareTo(PriorityVertex other) {
		int num = Double.valueOf(distanceFromSource).compareTo(other.distanceFromSource);
		return num;
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof PriorityVertex)) {
			return false;
		}
		PriorityVertex other = (PriorityVertex) obj;
		if(vertex == other.vertex) {
			return true;
		}
		else {
			return false;
		}
		
	}
}
