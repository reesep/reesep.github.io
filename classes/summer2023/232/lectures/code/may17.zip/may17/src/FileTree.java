import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class FileTree {

	private Node root;
	private Node current;
	
	public FileTree() {
		this.root = new Node("~");
		this.current = root;
	}
	
	public boolean insert(String directory){
		if( directory == null || directory.equals(" ") || directory.equals("~")) {
			return false;
		}
		else {
			Node newNode = new Node(directory);
			newNode.setParent(current);
			current.addChild(newNode);
			return true;
		}
	}
	
	public boolean moveDown(String directory) {
		//TO DO Lab 2: Modify this method to allow for full path (hint: use .split())
		ArrayList<Node> children = current.getChildren();
		for(Node child: children) {
			if(child.getName().equals(directory)) {
				current = child;
				return true;
			}
		}
		return false;
	}
	
	public void moveUp() {
		
		if( current != root ) {
			current = current.getParent();
		}
		
	}
	
	public void goHome() {
		current = root;
	}
	
	public String getCurrentLocation() {
		return current.getName();
	}
	
	public String getChildrenDirectories() {
		String files = "";
		ArrayList<Node> children = current.getChildren();
		for(Node c: children) {
			files += c.getName() + " ";
		}
		return files;
	}

	public boolean remove(String directory) {
		// TO DO: Lab 2. Remove directory.
		return false;
	}

	public String getPath() {
		// TO DO: Lab 2. Get full path of current directory
		return null;
	}
	
	public void breadthFirst() {
		Queue<Node> queue = new LinkedList<Node>();
		if( root != null) {
			queue.add(root);
			while( !queue.isEmpty()) {
				
				Node node = queue.remove();
				System.out.println(node.getName());
				for(Node n: node.getChildren()) {
					queue.add(n);
				}
				
			}
		}
	}
	
}
