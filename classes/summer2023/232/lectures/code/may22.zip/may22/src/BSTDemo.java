
public class BSTDemo {

	public static void main(String[] args) {
		
		BST bst = new BST();
		bst.insert(44);
		bst.insert(17);
		bst.insert(88);
		bst.insert(8);
		bst.insert(32);
		bst.insert(65);
		
		bst.depthFirst(bst.root);

	}

}
