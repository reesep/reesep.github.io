
public class BST {

	Node root;
	
	public BST() {
		root = null;
	}
	
	public int getMin() {
		// TO DO LAB 3: Return the minimum value in the BST
		// move left as far as possible
		
		return -1;
	}
	
	public int getMax() {
		//TO DO LAB 3: Return the maximum value in the BST
		// move right as far as possible
		
		return -1;
	}
	
	public void depthFirst(Node n) {
		
		if(n != null) {
			System.out.println(n.getValue());
		}
		else if(n == null) {
			// do nothing
			return;
		}
		depthFirst(n.getLeft());
		depthFirst(n.getRight());
		
		
	}
	
	
	
	public void insert(int newValue) {
	
		if(root == null) { //if tree is empty
			root = new Node(newValue);
		}
		else {  //if tree is not empty
			
			Node currentNode = root;
			boolean placed = false;
			while(!placed) {
				
				if( newValue == currentNode.getValue()) {
					placed = true;
					System.out.println("Cannot have duplicate value");
				}
				else if( newValue < currentNode.getValue()) {
					if(currentNode.getLeft() == null) { // if path does not exist on the left
						currentNode.setLeft(new Node(newValue));
						currentNode.getLeft().setParent(currentNode);
						placed = true;
					}
					else { // if a path exists on the left
						currentNode = currentNode.getLeft(); //follow left path
					}
				}
				else {
					if( currentNode.getRight() == null) { //if right path does not exist
						currentNode.setRight(new Node(newValue));
						currentNode.getRight().setParent(currentNode);
						placed = true;
					}
					else { //right path exists
						currentNode = currentNode.getRight();
					}
				}
				
				
				
			}
			
			
		}
		
		
	}
	
	
}
