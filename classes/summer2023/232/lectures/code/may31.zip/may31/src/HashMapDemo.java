
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		
		HashMap<String, String> pirate = new HashMap<String, String>();
		
		pirate.put("hello", "ahoy");
		pirate.put("friend", "matey");
		pirate.put("yes", "aye");
		pirate.put("stop", "heave");
		pirate.put("CSCI232", "Davey Jones's Locker");
		pirate.put("treasure", "booty");
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a sentence: ");
		String input = in.nextLine();
		
		String[] words = input.split(" ");
		String new_sentence = "";
		for(String each_word: words) {
			
			//pull the pirate translation
			String pirate_word = pirate.get(each_word.toLowerCase());
			if(pirate_word != null) {
				new_sentence += pirate_word + " ";
			}
			else {
				new_sentence += each_word + " ";
			}
		}
		System.out.println(new_sentence);
		
	}

}
