import java.util.LinkedList;
import java.util.Queue;

public class StackAndQueueDemo {

	public static void main(String[] args) {
		
		Queue<String> queue = new LinkedList<String>();
		
		queue.add("AAA");
		queue.poll();
		

	}

}
