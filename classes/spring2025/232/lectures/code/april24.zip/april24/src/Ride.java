
public class Ride {

	int start;
	int end;
	int tip;
	
	public Ride(int s, int e, int t) {
		this.start = s;
		this.end = e;
		this.tip = t;
	}
	
	
}
