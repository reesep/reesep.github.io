
public class HuffmanNode implements Comparable<HuffmanNode>{

	private char character;
	private int frequency;
	
	private HuffmanNode left;
	private HuffmanNode right;
	
	//leaf node
	public HuffmanNode(char c, int f) {
		this.character = c;
		this.frequency = f;
		this.left = null;
		this.right = null;
	}
	
	//internal node
	public HuffmanNode(HuffmanNode first, HuffmanNode second) {
		this.frequency = first.getFrequency() + second.getFrequency();
		this.left = first;
		this.right = second;
		this.character = '*';
	}
	
	public char getCharacter() {
		return this.character;
	}
	public int getFrequency() {
		return this.frequency;
	}

	@Override
	public int compareTo(HuffmanNode other) {
	
		if(this.frequency > other.frequency) {
			return 1;
		}
		else if(this.frequency == other.frequency) {
			return 0;
		}
		else {
			return -1;
		}
		
	}

	public HuffmanNode getLeft() {
		// TODO Auto-generated method stub
		return left;
	}

	public HuffmanNode getRight() {
		// TODO Auto-generated method stub
		return right;
	}
	
	
	
	
}
