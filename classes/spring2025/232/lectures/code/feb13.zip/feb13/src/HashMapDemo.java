import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		
		HashMap<String, String> map = new HashMap<String, String>();
		HashSet<String> set = new HashSet<String>();
		
		set.add("First");
		set.add("Second");
		set.add("Third");
		set.add("Fourth");
		System.out.println(set.contains("Third"));
		System.out.println(set);
		
		map.put("Dallas","Cowboys");
		
		map.put("Philidelphia", "Eagles");
		
		Set<String> keys = map.keySet();
		
		for(String key: keys) {
			System.out.println(key + " " + map.get(key));
		}
		
		System.out.println(map.get("Seattle"));
		System.out.println(map);
		
	}

}
