import java.util.HashMap;
import java.util.Scanner;

public class PirateTranslator {

	public static void main(String[] args) {
		
		HashMap<String, String> translator = new HashMap<String, String>();
		//populate the HashMap with english --> pirate mappings
		translator.put("hello", "ahoy");
		translator.put("friend", "matey");
		translator.put("yes", "aye");
		translator.put("stop", "heave");
		translator.put("CSCI232", "Davey Jones's Locker");
		
		//get a sentence (english) with scanner
		Scanner input = new Scanner(System.in);
		String sentence = input.nextLine().toLowerCase();
		String[] splitted = sentence.split(" ");
	
		//iterate through all words in the sentence
		String pirate_sentence = "";
		for(String word: splitted) {
			//construct new pirate sentence
			if(translator.containsKey(word)) {
				pirate_sentence += translator.get(word) + " ";
			}
			else {
				pirate_sentence += word + " ";
			}
	
		}
		System.out.println(pirate_sentence);

	}

}
